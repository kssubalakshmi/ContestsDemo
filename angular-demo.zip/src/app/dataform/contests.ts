export class Contests {

    id: string;
    name: string;
    type: string;
    phase: string;
    frozen: boolean;
    durationSeconds: string;
    startTimeSeconds: string;
    relativeTimeSeconds: string;
}
