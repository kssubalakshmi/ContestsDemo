import { Contests } from './contests';

describe('Contests', () => {
  it('should create an instance', () => {
    expect(new Contests()).toBeTruthy();
  });
});
