import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { Router } from '@angular/router';

import {MatTableDataSource} from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { Contests } from '../dataform/contests';
import { ClientService } from '../service/client.service';

@Component({
  selector: 'app-contests',
  templateUrl: './contests.component.html',
  styleUrls: ['./contests.component.css']
})
export class ContestsComponent implements OnInit {

  displayedColumns: string[] = ['id', 'name', 'phase', 'Type'];
  dataSource: MatTableDataSource<Contests>;

  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild('paginator', { static: true }) paginator: MatPaginator;
  // @ViewChild('matSort', { static: true }) matSort: MatSort;


  jsonArray: any[] = []

  contestsObj: Contests[] = [];

  constructor(private router: Router,
    private zone: NgZone,
    private clientService :ClientService) {
  }


  ngOnInit() {
    this.getJSONData();
    //this.dataSource.sort = this.sort;
  }

  getJSONData(){
    this.clientService.getDataFromURL().subscribe(resp => {
      this.contestsObj = resp as Contests[];
      console.log(resp['result'])
      this.dataSource = new MatTableDataSource<Contests>(resp['result']);
      this.dataSource.paginator = this.paginator;
       this.dataSource.sort = this.sort;
    })
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

}
