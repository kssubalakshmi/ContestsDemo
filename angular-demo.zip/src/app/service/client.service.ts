import { Injectable, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  public static readonly URL_JSON_LIST = "https://codeforces.com/api/contest.list"

  constructor(private router: Router,
    private zone: NgZone,
    private http: HttpClient) { }

    getDataFromURL() {
      return this.http.get(ClientService.URL_JSON_LIST)
       .pipe(catchError(this.handleError('Request Failed')));
    }

    
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: HttpErrorResponse) => {
      console.log(error);
      if (error.status === 401) {
        window.location.replace('');
      }
      return Observable.throw(error);
    };
  }
}
