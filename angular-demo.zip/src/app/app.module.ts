import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatCardModule} from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatInputModule} from '@angular/material';
import { ClientService } from './service/client.service';
import { ContestViewComponent } from './contest-view/contest-view.component';
import { ContestsComponent } from './contests/contests.component';





@NgModule({
  declarations: [
    AppComponent,
    ContestViewComponent,
    ContestsComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule, 
    MatCardModule,
    MatPaginatorModule,
    MatTableModule,
    MatInputModule,
    MatFormFieldModule,
    AppRoutingModule, BrowserAnimationsModule
  ],
  providers: [ClientService],
  bootstrap: [AppComponent]
})
export class AppModule { }
