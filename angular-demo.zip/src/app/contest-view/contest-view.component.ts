import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contest-view',
  templateUrl: './contest-view.component.html',
  styleUrls: ['./contest-view.component.css']
})
export class ContestViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
