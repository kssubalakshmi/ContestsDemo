import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContestViewComponent } from './contest-view/contest-view.component';
import { ContestsComponent } from './contests/contests.component';


const routes: Routes = [

  { path: '',   redirectTo: '/contests', pathMatch: 'full' },
  { path: 'contests', component: ContestsComponent },
  { path: 'contestView/:id', component: ContestViewComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
